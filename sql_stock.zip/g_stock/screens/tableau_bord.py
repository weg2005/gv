from kivy.uix.screenmanager import Screen
from kivy.graphics import Color, RoundedRectangle, Rectangle
from kivy.uix.image import Image
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.clock import Clock
from database.datacaisse import last_time, cummule_jour, cummele_recette, nom_actuel, get_top_products, get_sales_by_hour
import os

# Importation de Kivy Garden Graph
from kivy_garden.graph import Graph, MeshLinePlot

class TableauBord(Screen):
    def __init__(self, **kwargs):
        super(TableauBord, self).__init__(**kwargs)
        
        Clock.schedule_interval(self.actualliser, 1)
        Clock.schedule_interval(self.actualliser_graph, 10)

        box_title = BoxLayout(
            orientation='vertical',
            padding=10,
            spacing=10,
            pos_hint={'x': 0., 'y': 0.85},
            size_hint=(1, 0.15)
        )
        
        self.title = Label(
            text="TABLEAU DE BORD\n Avoir un aperçu global de la vente",
            color=(1, 1, 1, 1),
            font_size=20,
            font_name="Roboto-Bold.ttf"
        )
        box_title.add_widget(self.title)
        
        self.sorti = Button(
            text="Sortir >",
            background_color=(0, 0, 0, 0), 
            background_normal='',
            background_down="",
            font_name="Roboto-Bold.ttf",
            font_size=20
        )
        self.sorti.bind(on_press=self.retour)
        box_title.add_widget(self.sorti)
        self.add_widget(box_title)
       
        # INFORMATIONS RAPIDES
        box_information = BoxLayout(
            padding=10,
            spacing=10,
            size_hint=(1, 0.15),
            pos_hint={'x': 0, 'y': 0.71}
        )
        
        self.nombre_vente = Button(
            text="Nom du\ndernier\ncaissier\n",
            color=(1, 1, 1, 1),
            font_name='Roboto-Bold.ttf',
            font_size=20,
            background_color=(0, 0, 0, 0.15)
        )
        box_information.add_widget(self.nombre_vente)
        
        self.solde_caisse = Button(
            text="Solde\nde\ncaisse\n0",
            font_size=20,
            font_name='Roboto-Bold.ttf',
            color=(1, 1, 1, 1),
            background_color=(0., 0., 0., 0.15)
        )
        box_information.add_widget(self.solde_caisse)
        
        self.dernier_vente = Button(
            text="Dernier\nvente\n",
            color=(1, 1, 1, 1),
            background_color=(0., 0., 0., 0.15),
            font_size=20,
            font_name='Roboto-Bold.ttf'
        )
        box_information.add_widget(self.dernier_vente)
        self.add_widget(box_information)
        
        # --- SECTION DEUX GRAPHIQUES COTE A COTE ---
        box = BoxLayout(
        spacing=10,
        padding=10,
        size_hint=(1, 0.37),
        pos_hint={'x': 0., 'y': 0.325})
        
        # Graphique 1 : Top Produits
        
        self.graph_produit = Graph(
        xlabel='Index',
        ylabel='Qte',
        y_grid_label=True,
        x_grid_label=True,
        padding=5,
        xmin=0,
        xmax=10,
        ymin=0,
        ymax=50)
        self.plot_produit = MeshLinePlot(
        color=[1, 1, 1, 1])
        self.graph_produit.add_plot(self.plot_produit)
        box.add_widget(self.graph_produit)
        
        # Graphique 2 : Ventes par Heure
        
        self.graph_heure = Graph(
        xlabel='Heure',
        ylabel='Somme',
        y_grid_label=True,
        x_grid_label=True,
        padding=5,
        xmin=0,
        xmax=24,
        ymin=0,
        ymax=10000
        )
        self.plot_heure = MeshLinePlot(
        color=[1, 1, 1, 1]
        )
        self.graph_heure.add_plot(self.plot_heure)
        box.add_widget(self.graph_heure)
        self.add_widget(box)
         
        # INFO RAPIDE (Ventes, Recettes, Dépenses)
        box_benef = BoxLayout(
            spacing=10,
            padding=10,
            size_hint=(1, 0.15),
            pos_hint={'x': 0, 'y': 0.165}
        )
        
        self.vente_jour = Button(
            text="Vente\ndu\njour\n0",
            font_name='Roboto-Bold.ttf',
            font_size=20,
            background_color=(0., 0., 0., 0.15)
        )
        box_benef.add_widget(self.vente_jour)
        
        self.button_recette = Button(
            text="Recette\ndu\njour\n0",
            background_color=(0., 0., 0., 0.15),
            font_size=20,
            font_name='Roboto-Bold.ttf'
        )
        box_benef.add_widget(self.button_recette)
        
        self.button_depense = Button(
            text="Depense\ndu\njour\n0",
            background_color=(0., 0., 0., 0.15),
            font_size=20,
            font_name='Roboto-Bold.ttf'
        )
        box_benef.add_widget(self.button_depense)
        self.add_widget(box_benef)
        
        # BUTTON ALERTE
        self.box_alerte = BoxLayout(
            spacing=10,
            padding=10,
            size_hint=(1, 0.06),
            pos_hint={'x': 0, 'y': 0.1}
        )
        
        icon_path = 'assets/images/images (1).jpeg'
        if os.path.exists(icon_path):
            self.img_exclamation = Image(source=os.path.abspath(icon_path), size_hint=(0.2, 1))
            
        
        self.message = Label(
            text='ALERTE SEUIL ATTEINT\nsolde de caisse atteint 200000fcfa pensez a faire un versement !',
            font_name="Roboto-Bold.ttf",
            font_size=16
        )
        
        
        
        # BUTTONS ACTIONS
        box_left = BoxLayout(
            padding=10, spacing=10,
            pos_hint={'x': 0.05, 'y': 0.01},
            size_hint=(0.4, 0.07)
        )
        self.versement = Button(
            text='Faire un versement',
            background_normal="", background_down='',
            color=(1, 1, 1, 1), background_color=(0, 0, 0, 0),
            font_name="Roboto-Bold.ttf"
        )
        self.versement.bind(on_press=self.screen_versement)
        box_left.add_widget(self.versement)
        self.add_widget(box_left)
        
        box_right = BoxLayout(
            padding=10, spacing=10,
            pos_hint={'x': 0.55, 'y': 0.01},
            size_hint=(0.4, 0.07)
        )
        self.historique = Button(
            text='Historique',
            background_normal="", background_down='',
            color=(1, 1, 1, 1), background_color=(0, 0, 0, 0),
            font_name="Roboto-Bold.ttf"
        )
        box_right.add_widget(self.historique)
        self.add_widget(box_right)
          
        
        with self.canvas.before:
            bg_path = 'assets/images/file_0000000074f07246a51a0f9ce144e4e3.png'
            self.rect_bord = Rectangle(source=os.path.abspath(bg_path) if os.path.exists(bg_path) else '')
            
        def update_rect_wight(*args):
            self.rect_bord.pos = self.pos
            self.rect_bord.size = self.size
        self.bind(pos=update_rect_wight, size=update_rect_wight)   
        
        with box_left.canvas.before:
            Color(0.5, 0, 0.5, 0.2)
            self.roun_left = RoundedRectangle()
            
        def resize_function_left(*args):
            self.roun_left.pos = box_left.pos
            self.roun_left.size = box_left.size
        box_left.bind(pos=resize_function_left, size=resize_function_left)
        
        with box_right.canvas.before:
            Color(0., 0., 0.8, 0.2)
            self.roun_right = RoundedRectangle()
            
        def resize_function_right(*args):
            self.roun_right.pos = box_right.pos
            self.roun_right.size = box_right.size
        box_right.bind(pos=resize_function_right, size=resize_function_right)

    def screen_versement(self, instance):
        self.manager.current = 'ScreenVersement'      
            
    def retour(self, instance):
        self.manager.current = 'acceil'  

    def actualliser(self, dt):
        d_heure = last_time()
        cumule = cummule_jour()
        recette = cummele_recette()
        nom, ticket = nom_actuel()
        seuil = 500000
  
        self.vente_jour.text = f"Vente\ndu\njour\n{cumule}"
        self.dernier_vente.text = f"Dernier\nvente\n{d_heure}"
        self.button_recette.text = f"Recette\ndu\njour\n{recette}"
        self.nombre_vente.text = f"Nom du\ndernier\ncaissier\n{nom}"
        self.solde_caisse.text = f"dernier\nticket de\ncaisse\n{ticket}"
        
        if float(cumule) >= seuil:
            self.box_alerte.add_widget(self.message)
            self.box_alerte.add_widget(self.img_exclamation)
            self.add_widget(self.box_alerte)
            
            # DESIGN VISUEL CANVAS
            with self.box_alerte.canvas.before:
                Color(1, 0., 0, 0.6)
                self.rect_alerte = RoundedRectangle(radius=[10])     
                           
    def update_bg_alerte(*args):
            self.rect_alerte.pos = box_alerte.pos
            self.rect_alerte.size = box_alerte.size
            self.box_alerte.bind(pos=update_bg_alerte, size=update_bg_alerte) 
        
    def actualliser_graph(self, dt):
        # Mise à jour Graphique 1 (Top Produits)
        data_produits = get_top_products(limite=5) # Limitons à 5 pour que la légende soit lisible
        points_prod = []
        legende_texte = "Légende Top Produits :\n"
        
        for index, (prod, qte) in enumerate(data_produits):
            points_prod.append((index + 1, float(qte) if qte else 0.0))
            legende_texte += f"{index + 1}: {prod} ({qte})\n"
            
        if points_prod:
            max_y1 = max([p[1] for p in points_prod])
            self.graph_produit.y_ymax = max_y1 * 1.2 if max_y1 > 0 else 10
            self.plot_produit.points = points_prod
            
        # Vous pouvez assigner ce texte à un Label de légende que vous aurez créé dans votre interface :
        # self.label_legende.text = legende_texte

        # Mise à jour Graphique 2 (Ventes par Heure)
        data_heures = get_sales_by_hour()
        points_heure = [(float(h), float(tot)) for h, tot in data_heures]
        if points_heure:
            max_y2 = max([p[1] for p in points_heure])
            self.graph_heure.y_ymax = max_y2 * 1.2 if max_y2 > 0 else 10000
            self.plot_heure.points = points_heure
