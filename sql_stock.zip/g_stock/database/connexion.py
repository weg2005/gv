import sqlite3

def connection():
    return sqlite3.connect("user_name")

def creer_tableuser():
    con = connection()
    cursor = con.cursor()
    cursor.execute ("CREATE TABLE IF NOT EXISTS user_names (NOM TEXT )")
    con.commit()
    con.close()
    
creer_tableuser()

def save_name (name,role):
    con = connection()
    cursor = con.cursor()
    cursor.execute ("INSERT INTO user_names VALUES  (?,?)",(name,role))
    con.commit()
    con.close()
    
def print_name() :
    con = connection()
    cursor = con.cursor()
    cursor.execute ("SELECT * FROM user_names")
    resultat = cursor.fetchall()
    con.commit()
    con.close()
    return resultat[0] if resultat else ""
    
    
def name_deleded (nom):
    con = connection()
    cursor = con.cursor()
    cursor.execute ("UPDATE user_names set NOM = ? WHERE NOM = ?",(nom,nom))
    con.commit()
    con.close()
    