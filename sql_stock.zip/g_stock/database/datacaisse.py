import sqlite3
import os 
from datetime import datetime

def dirname():
    dirname = os.path.dirname(os.path.abspath(__file__))
    pathname = os.path.join(dirname, "basecaisse.db")
    return pathname

def connection_sql() :
    connect = sqlite3.connect(dirname())
    return connect

def creer_table():
    connect = connection_sql()
    cursor = connect.cursor()
    cursor.execute(""" CREATE TABLE IF NOT EXISTS caissedata(ID INTEGER PRIMARY KEY AUTOINCREMENT,NOMCAISSIER TEXT, NOMPRODUIT TEXT, QTESORTI, DATESORTI TEXT, PRIX NUMERIC,SOMMETOTAL NUMERIC,RECU NUMERIC, DEVOIR NUMERIC,REMISE NUMERIC,COMPTEUR NUMERIC,RECETTE REAL,TYPEPAYE TEXT) """)
    connect.commit()
    connect.close()

def savecaisse_data (nom,designation,quantite,date,prix,somme,recu,devoir,remise,compteur,recette,typepaye):
    connect = connection_sql()
    cursor = connect.cursor()
    cursor.execute (""" INSERT INTO caissedata (NOMCAISSIER,NOMPRODUIT,QTESORTI,DATESORTI,PRIX,SOMMETOTAL,RECU,DEVOIR,REMISE,COMPTEUR,RECETTE,TYPEPAYE) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)""", (nom,designation,quantite,date,prix,somme,recu,devoir,remise,compteur,recette,typepaye))
    connect.commit()
    connect.close()

compte = 0   

def compteur_caisse():
    global compte
    compte += 1   
    return compte  

def get_top_products(limite = 10):
    """Récupère les meilleures ventes sous forme de liste de tuples (produit, quantite)"""
    connect = connection_sql()
    cursor = connect.cursor()
    cursor.execute("SELECT NOMPRODUIT, SUM(QTESORTI) as total FROM caissedata GROUP BY NOMPRODUIT ORDER BY total DESC LIMIT ?", (limite,))
    resultat = cursor.fetchall()
    connect.close()
    return resultat

def last_time():
    connect = connection_sql()
    cursor = connect.cursor()
    cursor.execute("select DATESORTI from caissedata order by ID desc limit 1")
    resultat = cursor.fetchone()
    connect.close()
    return resultat[0] if resultat else ''

def cummule_jour():
    connect = connection_sql()
    cursor = connect.cursor()
    date = datetime.now().strftime("%Y-%m-%d")
    cursor.execute("select sum (SOMMETOTAL) FROM caissedata where DATE (DATESORTI) like ?",(f"%{date}%",))
    resultat = cursor.fetchone()
    connect.close()
    return resultat[0] if resultat else ""

def cummele_recette():
    connect = connection_sql()
    cursor = connect.cursor()
    date = datetime.now().strftime("%Y-%m-%d")
    cursor.execute("select sum (RECETTE) from caissedata where DATE(DATESORTI) like ?",(f"%{date}%",))
    resultat = cursor.fetchone()
    connect.close()
    return resultat[0] if resultat else ""

def nom_actuel():
    connect = connection_sql()
    cursor = connect.cursor()
    cursor.execute("select NOMCAISSIER,COMPTEUR from caissedata order by ID desc limit 1")
    resultat = cursor.fetchall()
    connect.close()
    return resultat[0] if resultat else ''
