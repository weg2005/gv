import sqlite3
import os 
from datetime import datetime

def dirname():
    dirname = os.path.dirname(os.path.abspath(__file__))
    pathname = os.path.join(dirname, "basecaisse.db")
    return pathname

def connection_sql() :
    connect = sqlite3.connect(dirname())
    return connect

def creer_table():
    connect = connection_sql()
    cursor = connect.cursor()
    cursor.execute(""" CREATE TABLE IF NOT EXISTS caissedata(ID INTEGER PRIMARY KEY AUTOINCREMENT,NOMCAISSIER TEXT, NOMPRODUIT TEXT, QTESORTI, DATESORTI TEXT, PRIX NUMERIC,SOMMETOTAL NUMERIC,RECU NUMERIC, DEVOIR NUMERIC,REMISE NUMERIC,COMPTEUR NUMERIC,RECETTE REAL,TYPEPAYE TEXT) """)
    connect.commit()
    connect.close()

def savecaisse_data(nom,designation,quantite,date,prix,somme,recu,devoir,remise,compteur,recette,typepaye):
    connect = connection_sql()
    cursor = connect.cursor()
    cursor.execute (""" INSERT INTO caissedata (NOMCAISSIER,NOMPRODUIT,QTESORTI,DATESORTI,PRIX,SOMMETOTAL,RECU,DEVOIR,REMISE,COMPTEUR,RECETTE,TYPEPAYE) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)""", (nom,designation,quantite,date,prix,somme,recu,devoir,remise,compteur,recette,typepaye))
    connect.commit()
    connect.close()

compte = 0   

def compteur_caisse():
    global compte
    compte += 1   
    return compte  

def get_top_products(limite=10):
    connect = connection_sql()
    cursor = connect.cursor()
    cursor.execute("SELECT NOMPRODUIT, SUM(QTESORTI) as total FROM caissedata GROUP BY NOMPRODUIT ORDER BY total DESC LIMIT ?", (limite,))
    resultat = cursor.fetchall()
    connect.close()
    return resultat

def get_sales_by_hour():
    """Regroupe les ventes par heure pour le graphique horaire"""
    connect = connection_sql()
    cursor = connect.cursor()
    cursor.execute("SELECT DATESORTI, SOMMETOTAL FROM caissedata")
    rows = cursor.fetchall()
    connect.close()
    
    hourly_data = {}
    for row in rows:
        date_str, somme = row[0], row[1]
        if date_str and somme is not None:
            try:
                # Extraction de l'heure à partir de la date
                dt_obj = datetime.strptime(date_str.split('.')[0], "%Y-%m-%d %H:%M:%S" if " " in date_str else "%Y-%m-%d")
                hour = dt_obj.hour
                hourly_data[hour] = hourly_data.get(hour, 0.0) + float(somme)
            except Exception:
                pass
    return sorted(hourly_data.items())

def last_time():
    connect = connection_sql()
    cursor = connect.cursor()
    cursor.execute("select DATESORTI from caissedata order by ID desc limit 1")
    resultat = cursor.fetchone()
    connect.close()
    return resultat[0] if resultat else ''

def cummule_jour():
    connect = connection_sql()
    cursor = connect.cursor()
    date = datetime.now().strftime("%Y-%m-%d")
    cursor.execute("select sum (SOMMETOTAL) FROM caissedata where DATE (DATESORTI) like ?",(f"%{date}%",))
    resultat = cursor.fetchone()
    connect.close()
    return resultat[0] if resultat else 0.0

def cummele_recette():
    connect = connection_sql()
    cursor = connect.cursor()
    date = datetime.now().strftime("%Y-%m-%d")
    cursor.execute("select sum (RECETTE) from caissedata where DATE(DATESORTI) like ?",(f"%{date}%",))
    resultat = cursor.fetchone()
    connect.close()
    return resultat[0] if resultat else 0.0

def nom_actuel():
    connect = connection_sql()
    cursor = connect.cursor()
    cursor.execute("select NOMCAISSIER,COMPTEUR from caissedata order by ID desc limit 1")
    resultat = cursor.fetchone()
    connect.close()
    return resultat if resultat else ('', '')
